#My first attempt at a sad replacement for PhraseExpress...PyPhrase 1.0

#INSTALL/USAGE NOTE: To create a new phrase, simply place your new phrase in a .txt file
#in the "Phrases" directory naming the file with the name you'd like to type as your
#phrase. Example: if I want to type thanks to trigger my phrase, I would name the file
# thanks.txt

#NOTE TO USERS: The first three imports are native to all current (Python 3) installs,
#but the second two will take a short ammount of time to install the first time the script
#is run


import os
import sys
import time
try:
    import pyperclip
except:
    #If pyperclip is not installed, install it and then try re-importing
    os.system("pip install pyperclip");import pyperclip
try:
    import keyboard
except:
    #Install the keyboard module if necessary and re-import
    os.system("pip install keyboard");import keyboard

#A function to read the file to the clipboard
def copy(file):
    output=(open(file).read())
    #print(output)
    pyperclip.copy(output)

#Allow the user to input a "Phrase" which gets turned into a filename for retrieval
filename=("Phrases/"+str(input("Enter a Phrase =>"))+".txt")

#Run the copy function
copy(filename)

#Change back to the previous tab and paste the data
keyboard.send("alt+tab")
time.sleep(1)
keyboard.send("ctrl+v")

keyboard.unhook_all()
exit(0)
